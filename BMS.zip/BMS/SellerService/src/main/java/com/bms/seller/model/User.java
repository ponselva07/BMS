package com.bms.seller.model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import com.bms.seller.enums.AccountType;
import com.bms.seller.enums.Gender;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name = "AUCTION_USER")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "USER_ID")
	private Long userId;
	@Column(name = "FIRST_NAME")
	@NotEmpty(message="First name should not empty")
	private String firstName;
	@Column(name = "LAST_NAME")
	@NotEmpty(message="Last name should not empty")
	private String lastName;
	@Column(name = "DOB")
	private Date dob;
	@Column(name = "GENDER")
	private Gender gender;
	@Column(name = "EMAIL",unique=true,length=32)
	@NotEmpty(message="Email Id should not empty")
	private String email;
	@Column(name = "PHONE_NUMBER")
	private Long phoneNumber;
	@Column(name = "ACCOUNT_TYPE")
	private AccountType accountType;
	@Column(name = "PASSWORD")
	@NotEmpty(message="Password should not empty")
	private String password;
	@Column(name = "CONFIRM_PASSWORD")
	@NotEmpty(message="Confirm password should not empty")
	private String confirmPassword;
	@Column(name = "CREATED_ON")
	private Date createdOn;
	@Column(name = "UPDATED_ON")
	private Date updatedOn;
}
