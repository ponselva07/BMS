package com.bms.seller.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.bms.seller.enums.Status;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name = "PRODUCT")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "PRODUCT_ID")
	private Long productId;
	@Column(name = "PRODUCT_NAME",unique=true,length=32)
	private String productName;
	@ManyToOne
    @JoinColumn(name = "CATEGORY_ID")
	private Category category;
	@ManyToOne
    @JoinColumn(name = "SELLER_ID")
	private User user;
	@Column(name = "MINIMUM_PRICE")
	private Integer mimimumPrice;
	@Column(name = "STATUS")
	private Status status;
	@Column(name = "AUCTION_START_TIME")
	private Long startAuctionSession;
	@Column(name = "AUCTION_END_TIME")
	private Long endAuctionSession;
	@Column(name = "AUCTION_DATE")
	private Date auctionSessionDate;
	@Column(name = "CREATED_ON")
	private Date cretaedOn;
	@Column(name = "UPDATED_ON")
	private Date updatedOn;
}
