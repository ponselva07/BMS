package com.bms.seller.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bms.seller.model.Category;
import com.bms.seller.model.Product;
import com.bms.seller.model.User;
import com.bms.seller.service.SellerService;

@RestController
@RequestMapping("/auction")
public class SellerController {

	@Autowired
	SellerService service;

	@GetMapping(value = "/catogories", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Category>> getCatogoryList() {
		List<Category> categoryList = service.getCatogoryList();
		if (categoryList != null && categoryList.size() > 0) {
			return new ResponseEntity<List<Category>>(categoryList, HttpStatus.OK);
		}
		return new ResponseEntity<List<Category>>(HttpStatus.NOT_FOUND);
	}

	@PostMapping(value = "/product", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> submitProduct(@RequestBody Product product) {
		Product submittedProduct = service.submitProduct(product);
		if (submittedProduct != null) {
			return new ResponseEntity<Product>(submittedProduct, HttpStatus.CREATED);
		}
		return new ResponseEntity<Product>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@PutMapping(value="/product",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> updateProduct(Product product) {
		Product isProductAvailable = service.findByProductId(product.getProductId());
		if (isProductAvailable == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		service.updateProduct(product);
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@DeleteMapping(value="/product",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> deleteCatogory(Product product) {
		Product isProductAvailable = service.findByProductId(product.getProductId());
		if (isProductAvailable == null) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
		service.deleteCatogory(product);
		return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping(value = "/product/{productId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> getProductById(@PathVariable("productId") Long productId) {
		Product product = service.findByProductId(productId);
		if (product == null) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

	@GetMapping(value = "/bidders/{productId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<User>> getBidderList(@PathVariable("productId") Long productId) {
		List<User> bidderList = service.getBidderList(productId);
		if (bidderList != null && bidderList.size() > 0) {
			return new ResponseEntity<List<User>>(bidderList, HttpStatus.OK);
		}
		return new ResponseEntity<List<User>>(HttpStatus.NOT_FOUND);
	}
	
	@GetMapping(value = "/products/{sellerId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> getProductList(@PathVariable("sellerId") Long sellerId) {
		List<Product> productList = service.getProductList(sellerId);
		if (productList != null && productList.size() > 0) {
			return new ResponseEntity<List<Product>>(productList, HttpStatus.OK);
		}
		return new ResponseEntity<List<Product>>(HttpStatus.NOT_FOUND);
	}
	
	@GetMapping(value = "/products", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String,Product>>> getProductListByCategory() {
		List<Map<String,Product>> productListByCategory = service.getProductListByCategory();
		if (productListByCategory != null && productListByCategory.size() > 0) {
			return new ResponseEntity<List<Map<String,Product>>>(productListByCategory, HttpStatus.OK);
		}
		return new ResponseEntity<List<Map<String,Product>>>(HttpStatus.NOT_FOUND);
	}
}
