package com.bms.seller.enums;

public enum SessionStatus {
	Reserved,Unreserved
}
