package com.bms.admin.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bms.admin.dto.Login;
import com.bms.admin.model.User;
import com.bms.admin.service.EnrollmentService;


@RestController
@CrossOrigin
@RequestMapping("/auction")
public class EnrollmentController {

	@Autowired
	EnrollmentService service;
	
	@PostMapping(value="/register")
	public ResponseEntity<Object> registerAuctionUser(@Valid @RequestBody User user,BindingResult result) {
		if(result.hasErrors()) {
			return new ResponseEntity<>(result.getFieldError().getDefaultMessage(),HttpStatus.BAD_REQUEST);
		}else {
			User response=service.registerAuctionUser(user);
			return new ResponseEntity<>(response,HttpStatus.CREATED);	
		}
	}
	@PostMapping(value="/login")
	public ResponseEntity<String> loginAuctionUser(@Valid @RequestBody Login login,BindingResult result) {
		if(result.hasErrors()) {
			return new ResponseEntity<>(result.getFieldError().getDefaultMessage(),HttpStatus.BAD_REQUEST);
		}else {
			User user=service.loginAuctionUser(login);
			if(user != null)
				return new ResponseEntity<>(HttpStatus.OK);
			else
				return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
}
