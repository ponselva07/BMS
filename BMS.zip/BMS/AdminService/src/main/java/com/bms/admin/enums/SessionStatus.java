package com.bms.admin.enums;

public enum SessionStatus {
	Reserved,Unreserved
}
