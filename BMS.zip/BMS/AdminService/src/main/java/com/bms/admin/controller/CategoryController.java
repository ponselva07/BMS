package com.bms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import com.bms.admin.model.Category;
import com.bms.admin.service.CategoryService;

@RestController
@CrossOrigin
@RequestMapping("/auction")
public class CategoryController {

	@Autowired
	CategoryService service;

	@PostMapping(value="/catogory/{categoryName}/{userName}",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> createCatogory(@PathVariable("categoryName") String categoryName,
			UriComponentsBuilder ucBuilder) {
		Category category = service.createCatogory(categoryName);
		HttpHeaders headers = new HttpHeaders();
		if (category != null) {
			headers.setLocation(ucBuilder.path("/user/{id}").buildAndExpand(category.getCategoryId()).toUri());
			return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
		} 
		return new ResponseEntity<Void>(headers, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value="/catogory",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> updateCatogory(Category category) {
		Category isCategoryAvailable = service.findByCategoryId(category.getCategoryId());
		if (isCategoryAvailable == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		service.updateCatogory(isCategoryAvailable);
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@DeleteMapping(value="/catogory",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Category> deleteCatogory(Category category) {
		Category isCategoryAvailable = service.findByCategoryId(category.getCategoryId());
		if (isCategoryAvailable == null) {
			return new ResponseEntity<Category>(HttpStatus.NOT_FOUND);
		}
		service.deleteCatogory(category);
		return new ResponseEntity<Category>(HttpStatus.NO_CONTENT);
	}

	@GetMapping(value="/catogories",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Category>> getCatogoryList() {
		List<Category> categoryList = service.getCatogoryList();
		if (categoryList != null && categoryList.size() > 0) {
			return new ResponseEntity<List<Category>>(categoryList, HttpStatus.OK);
		}
		return new ResponseEntity<List<Category>>(HttpStatus.NOT_FOUND);
	}

	@GetMapping(value = "/catogory/{categoryId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Category> getCategoryById(@PathVariable("categoryId") Long categoryId) {
		Category category = service.findByCategoryId(categoryId);
		if (category == null) {
			return new ResponseEntity<Category>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Category>(category, HttpStatus.OK);
	}
}
