package com.bms.admin.dto;

import javax.validation.constraints.NotEmpty;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
public class Login {
	@NotEmpty(message="User name should not empty")
	private String userId;
	@NotEmpty(message="Password should not empty")
	private String password;
}
