package com.bms.admin.service;

import com.bms.admin.dto.Login;
import com.bms.admin.model.User;

public interface EnrollmentService {
	public User registerAuctionUser(User user);
	public User loginAuctionUser(Login login);
}
