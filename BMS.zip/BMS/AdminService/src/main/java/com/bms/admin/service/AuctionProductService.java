package com.bms.admin.service;

import java.util.List;
import java.util.Map;
import com.bms.admin.model.Product;


public interface AuctionProductService {
	List<Map<String, Product>> getProductListByCategory();
	Product approveOrDenyProduct(Product product);
}
