package com.bms.admin.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name = "AUCTION_SESSION")
public class AuctionSession {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "SESSION_ID")
	private Integer sessionId;
	@Column(name = "SESSION_DATE")
	private Date sessionDate;
	@Column(name = "SESSION_START_TIME")
	private Integer sessionStartTime;
	@Column(name = "SESSION_END_TIME")
	private Integer sessionEndTime;
	@Column(name = "CREATED_ON")
	private Date createdOn;
	@Column(name = "UPDATED_ON")
	private Date updatedOn;
	
}
