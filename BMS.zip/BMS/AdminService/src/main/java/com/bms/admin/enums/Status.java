package com.bms.admin.enums;

public enum Status {
	Active,Inactive
}
