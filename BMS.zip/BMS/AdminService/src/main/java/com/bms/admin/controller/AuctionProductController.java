package com.bms.admin.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bms.admin.model.Product;
import com.bms.admin.service.AuctionProductService;

@RestController
@CrossOrigin
@RequestMapping("/auction")
public class AuctionProductController {
	
	@Autowired
	AuctionProductService service;
	
	@GetMapping(value="/productList",produces=MediaType.APPLICATION_JSON_VALUE)
	public List<Map<String, Product>> getProductListByCategory(){
		return service.getProductListByCategory();
	}
	
	@PostMapping(value = "/product", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Product> approveOrDenyProduct(@RequestBody Product product) {
		Product isApprovedOrDeniedProduct = service.approveOrDenyProduct(product);
		if (isApprovedOrDeniedProduct != null) {
			return new ResponseEntity<Product>(HttpStatus.OK);
		}
		return new ResponseEntity<Product>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
