package com.bms.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bms.admin.model.Product;
import com.bms.admin.proxy.AuctionProductProxy;
@Service
public class AuctionProductServiceImpl implements AuctionProductService{

	
	AuctionProductProxy proxy;
	
	@Override
	public List<Map<String, Product>> getProductListByCategory() {
		return null;
	}

	@Override
	public Product approveOrDenyProduct(Product product) {
		return null;
	}

}
