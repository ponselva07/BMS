package com.bms.admin.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;

import com.bms.admin.model.AuctionSession;
import com.bms.admin.model.Category;
import com.bms.admin.service.AuctionSessionService;

@RestController
@RequestMapping("/auction")
public class AuctionSessionController {

	@Autowired
	AuctionSessionService service;

	@PostMapping(value = "/session", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> createSession(@RequestBody AuctionSession session) {
		AuctionSession sessionCreated = service.createSession(session);
		if (sessionCreated != null) {
			return new ResponseEntity<Void>(HttpStatus.CREATED);
		}
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@PutMapping(value = "/session", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<String> updateSession(AuctionSession session) {
		AuctionSession isSessionAvailable = service.findBySessionId(session.getSessionId());
		if (isSessionAvailable == null) {
			return new ResponseEntity<String>(HttpStatus.NOT_FOUND);
		}
		service.updateSession(session);
		return new ResponseEntity<String>(HttpStatus.OK);
	}

	@DeleteMapping(value = "/session", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Category> deleteCatogory(AuctionSession session) {
		AuctionSession isSessionAvailable = service.findBySessionId(session.getSessionId());
		if (isSessionAvailable == null) {
			return new ResponseEntity<Category>(HttpStatus.NOT_FOUND);
		}
		service.deleteSession(session);
		return new ResponseEntity<Category>(HttpStatus.NO_CONTENT);
	}

	@GetMapping(value = "/sessions", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<AuctionSession>> getSessionList() {
		List<AuctionSession> sessionList = service.getSessionList();
		if (sessionList != null && sessionList.size() > 0) {
			return new ResponseEntity<List<AuctionSession>>(sessionList, HttpStatus.OK);
		}
		return new ResponseEntity<List<AuctionSession>>(HttpStatus.NOT_FOUND);
	}

}
