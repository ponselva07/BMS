package com.bms.admin.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bms.admin.model.AuctionSession;

@Service
public class AuctionSessionServiceImpl implements AuctionSessionService{

	@Override
	public AuctionSession createSession(AuctionSession session) {
		return null;
	}

	@Override
	public AuctionSession findBySessionId(Integer sessionId) {
		return null;
	}

	@Override
	public AuctionSession updateSession(AuctionSession session) {
		return null;
	}

	@Override
	public void deleteSession(AuctionSession session) {
		
	}

	@Override
	public List<AuctionSession> getSessionList() {
		return null;
	}

}
