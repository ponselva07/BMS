import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PageNotFoundComponent } from '../page-not-found/page-not-found.component';
import { LoginComponent } from '../login/login.component';
import { RegistrationComponent } from '../registration/registration.component';
import { AdminComponent } from '../admin/admin.component';
import { BidderComponent } from '../bidder/bidder.component';
import { SellerComponent } from '../seller/seller.component';
import { AdminLayoutComponent } from '../admin-layout.component';

const appRoutes:Routes = [
  {path:'login',component:LoginComponent},
  {
    path: 'admin', component: AdminLayoutComponent,
    children: [
      {path:'bidder',component:BidderComponent},
      {path:'seller',component:SellerComponent}
    ]
  },
  //{path:'bidder',component:BidderComponent,outlet:'menubar'},
  //{path:'seller',component:SellerComponent,outlet:'menubar'},
  //{path:'admin',component:AdminComponent},
  {path:'register',component:RegistrationComponent},
  {path:'',redirectTo:'/login',pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent}
];
@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports:[
    RouterModule
  ],
  declarations: []
})
export class AppRoutingModule { }
