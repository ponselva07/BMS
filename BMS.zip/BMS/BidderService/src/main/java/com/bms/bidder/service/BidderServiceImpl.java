package com.bms.bidder.service;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bms.bidder.model.BiddingHistory;
import com.bms.bidder.model.Product;
import com.bms.bidder.proxy.SellerProxy;
import com.bms.bidder.repository.BidderRepository;

@Service
public class BidderServiceImpl implements BidderService{

	@Autowired
	BidderRepository repository;
	@Autowired
	SellerProxy sellerProxy;
	
	@Override
	public List<Map<String, Product>> getProductListByCategory() {
		return null;
	}

	@Override
	public BiddingHistory registerParticipation(Product product) {
		return null;
	}

}
