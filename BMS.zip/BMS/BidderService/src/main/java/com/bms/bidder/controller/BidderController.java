package com.bms.bidder.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bms.bidder.model.BiddingHistory;
import com.bms.bidder.model.Product;
import com.bms.bidder.service.BidderService;


@RestController
@RequestMapping("/auction")
public class BidderController {
	
	@Autowired
	BidderService service;
	
	@GetMapping(value = "/products", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Map<String,Product>>> getProductListByCategory() {
		List<Map<String,Product>> productListByCategory = service.getProductListByCategory();
		if (productListByCategory != null && productListByCategory.size() > 0) {
			return new ResponseEntity<List<Map<String,Product>>>(productListByCategory, HttpStatus.OK);
		}
		return new ResponseEntity<List<Map<String,Product>>>(HttpStatus.NOT_FOUND);
	}
	
	@PostMapping(value="/product",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Void> registerParticipation(@RequestBody Product product) {
		BiddingHistory biddingHistory = service.registerParticipation(product);
		if (biddingHistory != null) {
			return new ResponseEntity<Void>(HttpStatus.CREATED);
		} 
		return new ResponseEntity<Void>(HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
}
