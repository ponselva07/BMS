package com.bms.bidder.enums;

public enum AccountType {
	Seller,Bidder,Admin
}
