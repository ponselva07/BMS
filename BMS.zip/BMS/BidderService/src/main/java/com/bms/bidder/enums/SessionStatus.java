package com.bms.bidder.enums;

public enum SessionStatus {
	Reserved,Unreserved
}
