package com.bms.bidder.proxy;

public class SellerProxy {

}
