package com.bms.bidder.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@EqualsAndHashCode
@ToString
@Entity
@Table(name = "CATEGORY")
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CATEGORY_ID")
	private Long categoryId;
	@Column(name = "CATEGORY_NAME",unique=true,length=32)
	private String categoryName;
	@Column(name = "ADMIN_USER_ID")
	private Integer userId;
	@Column(name = "CREATED_ON")
	private Date createdOn;
	@Column(name = "UPDATED_ON")
	private Date updatedOn;
}
